﻿using System;

namespace ShipMission
{
    public class Корабль
    {
        int попаданий;

        public Точка[] палуба
        { get; private set; }

        public Корабль(Точка [] палуба)
        {
            this.палуба = палуба;
            попаданий = 0;
        }

        public Точка[] Палуба()
        {
            return палуба;
        }

        public Статус Выстрел(Точка t)
        {
            bool попал = false;
            for (int j = 0; j < палуба.Length; j++)
                if (палуба[j].Equals (t))
                    попал = true;
            if (попал)
            {
                попаданий++;
                if (попаданий == палуба.Length)
                    return Статус.убил;
                else
                    return Статус.ранил;
            }
            return Статус.мимо;
        }
    }
}
