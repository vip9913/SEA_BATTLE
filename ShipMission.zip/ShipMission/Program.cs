﻿using System;
using System.Threading;

namespace ShipMission
{
    class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }

        Редактор sea;

        void Start ()
        {
            sea = new Редактор();
            sea.ПоставитьРовно();
            ShowSea();
            Mission mission = new Mission(sea);
            Статус status;
            Точка target;
            do
            {
                status = mission.Fight (out target);
                ShowFight(target, status);
                Thread.Sleep(100);
            } while (status != Статус.победил);
            Console.ReadKey();
        }

        void ShowSea()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Точка coord = new Точка(0, 0);
            for (coord.x = 0; coord.x < Море.размер_моря.x; coord.x ++)
            for (coord.y = 0; coord.y < Море.размер_моря.y; coord.y ++)
                WriteAt(coord, " ");
            Console.BackgroundColor = ConsoleColor.Black;
        }

        void ShowFight(Точка target, Статус status)
        {
            WriteAt(new Точка(12, 2), "Steps: " + sea.шагов.ToString());
            WriteAt(new Точка(12, 4), "Kills: " + sea.убито.ToString());
            WriteAt(new Точка(12, 6), "Ships: " + sea.стоит.ToString());
            switch (status)
            {
                case Статус.неизвестно: WriteAt(target, " "); break;
                case Статус.мимо      : WriteAt(target, "."); break;
                case Статус.ранил     : WriteAt(target, "o"); break;
                case Статус.убил      : WriteAt(target, "O"); break;
                case Статус.победил   : WriteAt(target, "#"); break;
            }
        }

        void WriteAt(Точка coord, string text)
        {
            Console.SetCursorPosition(coord.x+1, coord.y+1);
            Console.Write(text);
        }


    }
}
