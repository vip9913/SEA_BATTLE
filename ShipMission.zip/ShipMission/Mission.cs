﻿using System;

namespace ShipMission
{
    public class Mission
    {
        Море sea;
        Random rand;

        public Mission(Море sea)
        {
            this.sea = sea;
            rand = new Random();
        }

        public Статус Fight (out Точка target)
        {
            do
            {
                target = new Точка(
                    rand.Next(0, Море.размер_моря.x), 
                    rand.Next(0, Море.размер_моря.y)); 
            } while (sea.КартаПопаданий(target) != Статус.неизвестно);
            return sea.Выстрел(target);
        }
    }
}
